Written in latest Version of C++
Used Visual Studio Code C++ extension
Compiled using 'g++ -g -std=c++11 -Wall -Wextra -Wno-sign-compare *.cpp' in the console.
Produced the correct output for lab1 on linux machine and local machine.
Produced no memory leaks from lab1's main.
